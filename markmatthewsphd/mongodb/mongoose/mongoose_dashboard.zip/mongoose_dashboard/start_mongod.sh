#!/usr/bin/env bash

cd  D:/MongoDB/Server/4.0/bin/
./mogod

