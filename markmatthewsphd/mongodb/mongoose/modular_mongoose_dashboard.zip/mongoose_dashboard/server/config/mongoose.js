const mongoose = require('mongoose');

// mongoose connnection to MongoDB
mongoose.connect('mongodb://localhost/basic_mongoose');