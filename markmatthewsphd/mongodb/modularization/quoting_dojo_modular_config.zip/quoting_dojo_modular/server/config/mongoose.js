const mongoose = require('mongoose');
// mongoose connection to MongoDB
mongoose.connect('mongodb://localhost/basic_mongoose');